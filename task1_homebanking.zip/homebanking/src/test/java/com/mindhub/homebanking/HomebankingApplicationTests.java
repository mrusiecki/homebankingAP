package com.mindhub.homebanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomebankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
